package com.S3.Client.javas3client.object;

import com.S3.Client.javas3client.AWSClient;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;

@Component
public class ObjectBase {

    @Autowired
    private AWSClient s3Client;

    public void putObjectWithContent(String bucketName , String objectName, String content){
        System.out.println("putObject enter");
        try {
            s3Client.getS3Client().putObject(bucketName, objectName, content);
        } catch (AmazonServiceException e){
            System.err.println("status code:"+e.getStatusCode());
            System.err.println("error code:"+e.getErrorCode());
            System.err.println("error message:"+e.getErrorMessage());
        } catch (Exception e){
            System.err.println("error message:"+e.getMessage());
        } finally {
            System.out.println("putObject exit");
        }
    }

    public void putObjectWithFile(String bucketName , String objectName, File file)throws IOException{
        System.out.println("putObjectWithFile enter");
        try {
            PutObjectRequest request = new PutObjectRequest(bucketName, objectName, file);
            s3Client.getS3Client().putObject(request);
        } catch (AmazonServiceException e){
            System.err.println("status code:"+e.getStatusCode());
            System.err.println("error code:"+e.getErrorCode());
            System.err.println("error message:"+e.getErrorMessage());
        } catch (Exception e){
            System.err.println("error message:"+e.getMessage());
        } finally {
            System.out.println("putObjectWithFile exit");
        }
    }

    public void deleteObject(String bucketName, String objectName){
        System.out.println("deleteObject enter");
        try{
            s3Client.getS3Client().deleteObject(bucketName, objectName);
        } catch (AmazonServiceException e){
            System.err.println("status code:"+e.getStatusCode());
            System.err.println("error code:"+e.getErrorCode());
            System.err.println("error message:"+e.getErrorMessage());
        } catch (Exception e){
            System.err.println("error message:"+e.getMessage());
        } finally {
            System.out.println("deleteObject exit");
        }
    }

    public void getObject(String bucketName, String objectName){
        System.out.println("getObject enter");
        S3ObjectInputStream s3is = null;
        FileOutputStream fos = null;
        try{
            GetObjectRequest request = new GetObjectRequest(bucketName, objectName, null);
            S3Object result = s3Client.getS3Client().getObject(request);

            s3is = result.getObjectContent();
            File file = new File(objectName);
            System.out.println("file path:" + file.getAbsolutePath());
            fos = new FileOutputStream(file);
            byte[] read_buf = new byte[1024 * 1024];
            int read_len;
            while ((read_len = s3is.read(read_buf)) > 0) {
                fos.write(read_buf, 0, read_len);
            }
            s3is.close();
            fos.close();
        } catch (AmazonServiceException e) {
            System.err.println("status code:"+e.getStatusCode());
            System.err.println("error code:"+e.getErrorCode());
            System.err.println("error message:"+e.getErrorMessage());
        } catch (Exception e){
            System.err.println("error message:"+e.getMessage());
        } finally {
            System.out.println("getObject exit");
            if (fos != null){
                try {
                    fos.close();
                }catch (Exception e){
                    System.err.println("fos.close() failed. e:"+e.getMessage());
                }
            }
            if (s3is != null){
                try {
                    s3is.close();
                }catch (Exception e){
                    System.err.println("s3is.close() failed. e:"+e.getMessage());
                }
            }
        }
    }
}
