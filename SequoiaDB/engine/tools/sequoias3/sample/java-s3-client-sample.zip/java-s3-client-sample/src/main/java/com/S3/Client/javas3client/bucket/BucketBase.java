package com.S3.Client.javas3client.bucket;

import com.S3.Client.javas3client.AWSClient;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BucketBase {

    @Autowired
    private AWSClient s3Client;

    public void putBucket(String bucketName){
        System.out.println("putBucket enter");
        try {
            s3Client.getS3Client().createBucket(bucketName);
        } catch (AmazonServiceException e) {
            System.err.println("status code:"+e.getStatusCode());
            System.err.println("error code:"+e.getErrorCode());
            System.err.println("error message:"+e.getErrorMessage());
        } catch (Exception e){
            System.err.println("error message:"+e.getMessage());
        } finally {
            System.out.println("putBucket exit");
        }
    }

    public void deleteBucket(String bucket){
        System.out.println("deleteBucket enter");
        try{
            DeleteBucketRequest request = new DeleteBucketRequest(bucket);
            s3Client.getS3Client().deleteBucket(request);
        } catch (AmazonServiceException e){
            System.err.println("status code:"+e.getStatusCode());
            System.err.println("error code:"+e.getErrorCode());
            System.err.println("error message:"+e.getErrorMessage());
        } catch (Exception e){
            System.err.println("error message:"+e.getMessage());
        } finally {
            System.out.println("deleteBucket exit");
        }
    }

    public void listBuckets(){
        System.out.println("listBuckets enter");
        try{
            List<Bucket> buckets = s3Client.getS3Client().listBuckets();
            System.out.println("bucket number:" + buckets.size());
            for (int i = 0; i < buckets.size(); i++) {
                Bucket bucket = buckets.get(i);
                System.out.println("bucketname:" + bucket.getName() +
                        ", date:" + bucket.getCreationDate());
            }
        } catch (AmazonServiceException e){
            System.err.println("status code:"+e.getStatusCode());
            System.err.println("error code:"+e.getErrorCode());
            System.err.println("error message:"+e.getErrorMessage());
        } catch (Exception e){
            System.err.println("error message:"+e.getMessage());
        } finally {
            System.out.println("listBuckets exit");
        }
    }

    public void listObjects(String bucketName){
        System.out.println("listObjects enter");
        try {
            ListObjectsV2Request request = new ListObjectsV2Request();
            request.setBucketName(bucketName);
            ListObjectsV2Result result = s3Client.getS3Client().listObjectsV2(request);

            List<String> commonPrefix = result.getCommonPrefixes();
            for (int i = 0; i< commonPrefix.size(); i++){
                System.out.println("commonPrefix:"+commonPrefix.get(i));
            }
            List<S3ObjectSummary> objectList =  result.getObjectSummaries();
            System.out.println("key count: "+objectList.size());
            for (int i = 0; i < objectList.size(); i++){
                System.out.println("key " +i + ": "+objectList.get(i).getKey());
            }
        } catch (AmazonServiceException e){
            System.err.println("status code:"+e.getStatusCode());
            System.err.println("error code:"+e.getErrorCode());
            System.err.println("error message:"+e.getErrorMessage());
        } catch (Exception e){
            System.err.println("error message:"+e.getMessage());
        } finally {
            System.out.println("listObjects exit");
        }
    }
}
