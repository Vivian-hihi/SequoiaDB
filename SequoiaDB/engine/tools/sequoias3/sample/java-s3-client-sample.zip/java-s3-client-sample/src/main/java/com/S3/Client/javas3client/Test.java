package com.S3.Client.javas3client;

import java.io.File;

public class Test {

    public static void main(String[] args){
        S3Client s3Client = new S3Client("http://192.168.10.71:8002");

        String regionName = "region0";
        String bucketName = "my-bucket";
        String objectName = "object1";
        File file = new File("example");

        s3Client.createRegion(regionName);

        s3Client.listregions();

        s3Client.getregion(regionName);

        s3Client.putBucket(bucketName, regionName);

        s3Client.putObjectWithContent(bucketName, objectName, "test content");

        s3Client.putObjectWithFile(bucketName, objectName, file);

        s3Client.listObjects(bucketName);

        s3Client.listBuckets();

        s3Client.shutdown();
    }
}
