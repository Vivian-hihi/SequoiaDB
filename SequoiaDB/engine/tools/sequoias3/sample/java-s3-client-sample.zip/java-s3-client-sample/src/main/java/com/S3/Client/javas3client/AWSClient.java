package com.S3.Client.javas3client;

import com.S3.Client.javas3client.bucket.BucketBase;

import com.S3.Client.javas3client.multipart.MultiPartUpload;
import com.S3.Client.javas3client.object.ObjectBase;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;

@Component
public class AWSClient {

    private AmazonS3 s3;

    @Autowired
    private BucketBase bucketBase;

    @Autowired
    private ObjectBase objectBase;

    @Autowired
    private MultiPartUpload multiPartUpload;

    @Autowired
    public AWSClient(){
        AWSCredentials credentials = new BasicAWSCredentials("ABCDEFGHIJKLMNOPQRST","abcdefghijklmnopqrstuvwxyz0123456789ABCD");

        String endPoint = "http://192.168.10.71:8002";
        AwsClientBuilder.EndpointConfiguration endpointConfiguration = new AwsClientBuilder.EndpointConfiguration(endPoint, null);

        s3 = AmazonS3ClientBuilder.standard()
                .withEndpointConfiguration(endpointConfiguration)
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .build();
    }

    public void test() throws Exception{
        String bucketName = "mybucket";
        String keyName = "example.txt";

        bucketBase.putBucket(bucketName);

        objectBase.putObjectWithContent(bucketName, keyName, "abcedfg");

//        objectBase.putObjectWithFile(bucketName, keyName, new File("D:\\tmp\\testObject.txt"));

        objectBase.getObject(bucketName, keyName);

        bucketBase.listObjects(bucketName);

        objectBase.deleteObject(bucketName, keyName);

//        multiPartUpload.multiPartUploadObject(bucketName, keyName, new File("D:\\tmp\\testUpload.txt"));
    }

    public AmazonS3 getS3Client(){
        return s3;
    }
}
