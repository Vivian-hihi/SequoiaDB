package com.S3.Client.javas3client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationListener;

@SpringBootApplication
public class JavaS3ClientApplication implements ApplicationRunner {

	@Autowired
	AWSClient awsClient;

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(JavaS3ClientApplication.class);
		app.setBannerMode(Banner.Mode.OFF);
		app.run(args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		awsClient.test();
	}
}
