/****************************************************
@description:	create collectionspace, normal case
@input:		run CURL command: 
				1 curl http://127.0.0.1:11814/ -d "create collection&name=local_test_cs.local_test_cl"
				2 curl http://127.0.0.1:11814/ -d "drop collection&name=local_test_cs.local_test_cl"
@expectation:	1 return errno:0
				2 return errno:0
@modify list:
            		2015-4-3 Ting YU init
****************************************************/
var csName=COMMCSNAME;
var clName=COMMCLNAME;
var cs="name="+csName;
var cl="name="+csName+'.'+clName;
var db = new Sdb( COORDHOSTNAME, COORDSVCNAME );
var isStandalone=false;

function createclAndCheck(){
	var word="create collection";
	tryCatch(
		["cmd="+word,cl,"options={ShardingKey:{age:1}}"] ,
		[0] ,
		"Fail to run rest [cmd="+word+"]");
	
	try
	{
	      db.getCS(csName).getCL(clName);
	}
	catch(e)
	{
		println( "Error: rest [cmd="+word+"] has been done, but cl["+cl+"] does not exist");
		throw e;
	}
	
	if(false==isStandalone)
	{
		var tep=db.snapshot(8,{Name:csName+'.'+clName}).current().toObj()["ShardingKey"];
	 	if (   JSON.stringify(tep)!='{"age":1}'    ){
	      	throw 'Error: options parameter Shardingkey, expect: {"age":1}, actual: '+JSON.stringify(tep);
	  	}	
  }		

}

function dropclAndCheck(){
	var word="drop collection";
	tryCatch(
		["cmd="+word,cl] ,
		[0] ,
		"Fail to run rest [cmd="+word+"]");
	
	try
	{	
		var flag=false;
	      db.getCS(csName).getCL(clName);
		flag=true;
	}
	catch ( e )
	{
		if(e!=-23)
		{
			println("Error: rest [cmd=drop collection]  has been done, cs.getCL("+clName+"), expect: return -23, actually: return "+e);
			throw e;
		}	
	}

	if (true==flag)
	{
		db.getCS(csName).dropCL(clName);
		throw "Error: rest [cmd=drop collection]  has been done, cs.getCL("+clName+"), expect: return -23, actually: return 0";
	}

}

try
{
	isStandalone=commIsStandalone(db);
}
catch(e)
{
	println("fail to get commIsStandalone() result!");
	throw e;
}
commDropCL(db, csName, clName, true, true,"drop cl in begin");
createclAndCheck();
dropclAndCheck();
db.close();
