/****************************************************
@description:	insert/delete/update/query
@expectation:	1 lackInInsert(): lack [insertor] expect: return -6
				2 lackInUpdate(): lack [updator/filter] expect: return -6
				3 lackInQuery(): lack [cmd] expect: return -100
@modify list:
            		2015-4-2 Ting YU init
****************************************************/
var csName=COMMCSNAME;
var clName=COMMCLNAME;
var cl="name="+csName+'.'+clName;
var db = new Sdb( COORDHOSTNAME, COORDSVCNAME );

function lackInInsert(){
	var word='insert';
	tryCatch(["cmd="+word,cl] , [-6] , "Error occurs in lackInInsert function");
}
function lackInUpdate(){
	var word='update';
	tryCatch(["cmd="+word,cl,'filter={"name":"Tom"}'] , [-6] , "Error occurs in lackInUpdate function; lack of updator");
	
	tryCatch(["cmd="+word,cl,'updator={$set:{"age";10}}'] , [-6] , "Error occurs in lackInUpdate function; lack of filter");
}

function lackInQuery(){
	var word='query';
	tryCatch([cl,'skip=1'] , [-100] , "Error occurs in lackInQuery function; lack of cmd");
}

commDropCL(db,csName,clName,true,true,"drop cl in begin");
var opt={ReplSize:0};
var varCL=commCreateCLByOption(db,csName,clName,opt,true,false,"create cl in begin");

lackInInsert();
lackInUpdate();
lackInQuery();

commDropCL(db, csName, clName, false,false, "drop cl in clean")
db.close();