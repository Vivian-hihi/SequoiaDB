/****************************************************
@description:	create/drop cl, abnormal case
@expectation:	1 lackNameCreateCL(): expect: return -6
				2 lackNameDropCL(): expect: return -6
@modify list:
            		2015-3-30 Ting YU init
****************************************************/
var csName=COMMCSNAME;
var db = new Sdb( COORDHOSTNAME, COORDSVCNAME );


function lackNameCreateCL(){
	tryCatch(["cmd=create collection"] , [-6] , "Error occurs in "+getFuncName());
}
function lackNameDropCL(){
	tryCatch(["cmd=drop collection"] , [-6] , "Error occurs in "+getFuncName());
}

db.close();