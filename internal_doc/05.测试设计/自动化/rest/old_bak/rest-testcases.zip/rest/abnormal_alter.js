/****************************************************
@description:	insert/delete/update/query
@expectation:	lackInAltercl(): lack [options] expect: return -6
@modify list:
            		2015-4-7 Ting YU init
****************************************************/
var csName=COMMCSNAME;
var clName=COMMCLNAME;
var cl="name="+csName+'.'+clName;
var db = new Sdb( COORDHOSTNAME, COORDSVCNAME );

function lackInAltercl(){
	var word='alter collection';
	tryCatch(["cmd="+word,cl] , [-6] , "Error occurs in "+getFuncName());
}

if(true==commIsStandalone(db))
{
	println("Mode is standalone!");
}
else{
	commDropCL(db,csName,clName,true,true,"drop cl in begin");
	var opt={ReplSize:0};
	var varCL=commCreateCLByOption(db,csName,clName,opt,true,false,"create cl in begin");
	
	lackInAltercl();
	
	commDropCL(db, csName, clName, false,false, "drop cl in clean");
}
db.close();