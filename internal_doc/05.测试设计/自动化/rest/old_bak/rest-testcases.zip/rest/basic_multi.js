/****************************************************
@description:	multi, normal case
@input:			1 drop non-existed cl in cs
					2 repeate step 1 30 times
@expectation:	return errno = -23; 
					if rest return empty, may be javascript shell is unnormal!
@modify list:
            		2015-4-22 Ting YU init
****************************************************/
var csName=COMMCSNAME;
var clName=COMMCLNAME;
var cl="name="+csName+'.'+clName;
var db = new Sdb( COORDHOSTNAME, COORDSVCNAME );
var time=30;

try{
	commDropCL(db,csName,clName,true,true,"drop cl in begin");
	var word="drop collection";
	for(var i=0;i<time;i++)
	{
		tryCatch(["cmd="+word,cl],[-23],word+" fail at "+i+" time, expect: return -23");
	}

	commDropCL(db, csName, clName, false,true, "drop cl in clean");

}
catch(e)
{
	throw e;
}
finally
{
	commDropCL(db, csName, clName, false,true, "drop cl in clean in finally");
	db.close();
}
