/* *****************************************************************************
@Description: subCL hash-split
@modify list:
   2014-07-30 pusheng Ding  Init
***************************************************************************** */

function test1() // NOT Error, check main CL and sub CL wheter have SourceGroupName , is the base of function split 
{
   MainCL_Name = CHANGEDPREFIX + "year" ;
   subCl_Name = CHANGEDPREFIX + "month" ;
   try
   {
      commDropCL( db, COMMCSNAME, subCl_Name+"1", true, true,
                  "clean sub collection" );
      commDropCL( db, COMMCSNAME, MainCL_Name, true, true,
                  "clean main collection" );
   }
   catch( e )
   {
      println( "failed to drop main and sub cl, rc = " + e );
      throw e;
   }

   try {
      var cs = commCreateCS( db, COMMCSNAME, true, "create cs in the beginning" );
   }catch(e){
      println( "failed to create cs, rc = " + e );
      throw e;
   }
   println( COMMCSNAME ) ;

   try
   {
      var mainCL = cs.createCL( MainCL_Name, { ShardingKey:{ a:1 },  Partition:4096, ReplSize:0, Compressed:true, IsMainCL:true } ) ;
   }
   catch( e )
   {
      println( "Can't create mainCL: " + e ) ;
      throw e ;
   }
   try
   {
      var subCL = cs.createCL( subCl_Name + "1", { ShardingKey:{ a:1 }, ShardingType: "hash", ReplSize:0, Compressed:true, IsMainCL:false } ) ;
   }
   catch( e )
   {
      println( "Can't create subCL: " + e );
   }

   var sourceDataGroupName = getSourceGroupName_alone( COMMCSNAME, subCl_Name + "1" );
   println( "sourceDataGroupName is : " + sourceDataGroupName ) ;
   var desDataGroupName = getOtherDataGroups( sourceDataGroupName ) ;
   println("desDataGroupName is "+desDataGroupName);
   var Partition = getPartition( COMMCSNAME, subCl_Name + "1" );
   println( "Partition is : " + Partition ) ;
   if( !subCL_split_hash( subCL, sourceDataGroupName, desDataGroupName, Partition) )
   {
      println( "************SPLIT SUCCED***************" ) ;
   }
   else
   {
      throw -1 ;
   }
   // clean
   commDropCL( db, COMMCSNAME, subCl_Name + "1", false, false,
               "clean sub collection" );
   commDropCL( db, COMMCSNAME, MainCL_Name, false, false,
               "clean main collection" );
   return 0 ;
}

// Add inspect standalone run mode
try
{
   // Inspect the run mode is standalone or not
   if( true == commIsStandalone( db ) )
      throw "ModeStandAlone" ;
   test1();
}
catch( e )
{
   if( "ModeStandAlone" == e )
      println( "The run mode is standalone" ) ;
   else
      throw e ;
}
