/* *****************************************************************************
@Description: attach hashCL and insert-data before split
@modify list:
   2014-07-30 pusheng Ding  Init
***************************************************************************** */

function test_range_attach_hash_insert_large_same_beforesplit() // 
{
	MainCL_Name = CHANGEDPREFIX + "year" ;
	subCl_Name = CHANGEDPREFIX + "month" ;
   try
   {
      commDropCL( db, COMMCSNAME, subCl_Name + "1", true, true,
                  "clean sub collection" );
      commDropCL( db, COMMCSNAME, subCl_Name + "2", true, true,
                  "clean sub collection" );
      commDropCL( db, COMMCSNAME, MainCL_Name, true, true,
                  "clean main collection" );
   }
   catch( e )
   {
      println( "failed to drop main and sub cl, rc = " + e );
      throw e;
   }

   try {
      var cs = commCreateCS( db, COMMCSNAME, true, "create cs in the beginning" );
   }catch(e){
      println( "failed to create cs, rc = " + e );
      throw e;
   }
	println( COMMCSNAME ) ;
	
	try
	{
		var mainCL = cs.createCL( MainCL_Name, { ShardingKey:{ a:1,b:-1 }, ShardingType: "range", ReplSize:0, Compressed:true, IsMainCL:true } ) ;
		println( "mainCL" );
		var subCL1 = cs.createCL( subCl_Name + "1", { ShardingKey:{ a:1 }, ShardingType: "hash", ReplSize:0, Compressed:true, IsMainCL:false } ) ;
		println( "subCL1" );
		var subCL2 = cs.createCL( subCl_Name + "2", { ShardingKey:{ a:1 }, ShardingType: "hash", ReplSize:0, Compressed:true, IsMainCL:false } ) ;
		println( "subCL2" );
		mainCL.attachCL( COMMCSNAME+"."+subCl_Name+"1", { LowBound:{a:0},UpBound:{a:1000} } ) ;
		println( "attach subCL1" ) ;
		mainCL.attachCL( COMMCSNAME+"."+subCl_Name+"2", { LowBound:{a:1000},UpBound:{a:2000} } ) ;
		println( "attach subCL2" ) ;
	}
	catch( e )
	{
		throw e ;
	}
	
	try 
	{
		for(var i = 0; i < 2000 ; ++i )
		{
			mainCL.insert( {a:i} ) ;
			mainCL.insert( {a:i+1,b:i+1} ) ;
			//mainCL.insert( {a:0,b:999} ) ;
		}
		println( " The first same data " ) ;
		for(var i = 0; i < 2000 ; ++i )
		{
			mainCL.insert( {a:i} ) ;
			mainCL.insert( {a:i+1,b:i+1} ) ;
			//mainCL.insert( {a:0,b:999} ) ;
		}
		println( " The second same data " ) ;
		for(var i = 0; i < 2000 ; ++i )
		{
			mainCL.insert( {a:i} ) ;
			mainCL.insert( {a:i+1,b:i+1} ) ;
			//mainCL.insert( {a:0,b:999} ) ;
		}
	}
	catch( e )
	{
		println( "i = " + i + ", err is :" + e ) ;
		throw e ;
	}
	
	try
	{
		var subCL = [] ;
		subCL.push( subCL1 ) ;
		subCL.push( subCL2 ) ;
		var numberOfsubCl = 2 ;
		for( var i = 0; i < numberOfsubCl; ++i )
		{
			var sourceDataGroupName = getSourceGroupName_alone( COMMCSNAME, subCl_Name + ( i + 1 ) );
			println( "sourceDataGroupName is : " + sourceDataGroupName ) ;
			
			var desDataGroupName = getOtherDataGroups( sourceDataGroupName ) ;
			println("desDataGroupName is "+desDataGroupName);
			
			var Partition = getPartition( COMMCSNAME, subCl_Name + ( i + 1 ) );
			println( "Partition is : " + Partition ) ;
			
			if( !subCL_split_hash( subCL[i], sourceDataGroupName, desDataGroupName, Partition) )
			{
				println( "************SPLIT SUCCED***************" ) ;
			}
		}
	}
	catch( e )
	{
		println( " Error: " + e );
		throw e ;
	}
	
	println( "mainCL max min value:" ) ;
	println( mainCL.find().sort( {a:1} ).limit( 1 ) ) ;
	println( mainCL.find().sort( {a:-1} ).limit( 1 ) ) ;
	
	println( "subCL1 max min value:" ) ;
	println( subCL1.find().sort( {a:1} ).limit( 1 ) ) ;
	println( subCL1.find().sort( {a:-1} ).limit( 1 ) ) ;
	
	println( "subCL2 max min value:" ) ;
	println( subCL2.find().sort( {a:1} ).limit( 1 ) ) ;
	println( subCL2.find().sort( {a:-1} ).limit( 1 ) ) ;
	
}

// Add inspect standalone run mode
try
{
   // Inspect the run mode is standalone or not
   if( true == commIsStandalone( db ) )
      throw "ModeStandAlone" ;
   test_range_attach_hash_insert_large_same_beforesplit();
}
catch( e )
{
   if( "ModeStandAlone" == e )
      println( "The run mode is standalone" ) ;
   else
      throw e ;
}
