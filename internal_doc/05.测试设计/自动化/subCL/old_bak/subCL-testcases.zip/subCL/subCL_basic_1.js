/* *****************************************************************************
@discretion: subCL basic: subcl hash-split
@modify list:
   						2014-01-30 Pusheng Ding  Init
***************************************************************************** */

function test_attach_hash() // NOT Error, check main CL and sub CL wheter have SourceGroupName , is the base of function split 
{
	mainCL_Name = CHANGEDPREFIX + "_year" ;
	subCL_Name = CHANGEDPREFIX + "_month" ;
	
	try
	{
		var db = new Sdb( COORDHOSTNAME, COORDSVCNAME ) ;
	}
	catch( e )
	{
		println( "can't new Sdb: " );
		throw e ;
	}
	try
	{
      commDropCL( db, COMMCSNAME, subCL_Name, true, true,
                  "drop cl in the beginning" ) ;
      commDropCL( db, COMMCSNAME, mainCL_Name, true, true,
                  "drop cl in the beginning" ) ;
	}
	catch( e )
	{
		if( e != -34 )
		{
			println( "can't dropCS, rc=" + e );
			throw e ;
		}
	}
	
	try
	{
      var cs = commCreateCS( db, COMMCSNAME, true, "create CS" );
		var mainCL = cs.createCL( mainCL_Name, { ShardingKey:{ a:1 },  Partition:4096, ReplSize:0, IsMainCL:true } ) ;
	}
	catch( e )
	{
		println( "Can't create mainCL: " + e ) ;
		throw e ;
	}
	try
	{
		var subCL = cs.createCL( subCL_Name , { ShardingKey:{ a:1 }, ShardingType: "hash", ReplSize:0, Compressed:true, IsMainCL:false } ) ;
	}
	catch( e )
	{
		println( "Can't create subCL: " + e );
      commDropCL( db, COMMCSNAME, COMMCLNAME, true, true,
                  "drop cl in the end" ) ;
	}
	println("create subcl finished!");
	
	var sourceDataGroupName = getSourceGroupName_alone( COMMCSNAME, subCL_Name );
	println( "sourceDataGroupName is : " + sourceDataGroupName ) ;
	var desDataGroupName = getOtherDataGroups( sourceDataGroupName ) ;
	println("desDataGroupName is "+desDataGroupName);
	var Partition = getPartition( COMMCSNAME, subCL_Name );
	println( "Partition is : " + Partition ) ;
	if( !subCL_split_hash( subCL, sourceDataGroupName, desDataGroupName, Partition) )
	{
		println( "************SPLIT SUCCED***************" ) ;
	}
	else
	{
		throw -1 ;
	}
	return 0 ;
}

// Add inspect standalone run mode
try
{
   var db = new Sdb(COORDHOSTNAME, COORDSVCNAME) ;
   // Inspect the run mode is standalone or not
   if( true == commIsStandalone( db ) )
      throw "ModeStandAlone" ;
   test_attach_hash();
}
catch( e )
{
   if( "ModeStandAlone" == e )
      println( "The run mode is standalone" ) ;
   else
      throw e ;
}
