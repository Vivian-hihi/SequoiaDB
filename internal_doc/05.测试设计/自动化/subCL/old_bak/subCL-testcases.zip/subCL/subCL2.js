/* *****************************************************************************
@Description: attach rangCL
@modify list:
   2014-07-30 pusheng Ding  Init
***************************************************************************** */

function test_range_attach_range() // NOT Error, test mainCL'ShardingType is range and subCL's ShardingType is range , attach's result
{
	MainCL_Name = CHANGEDPREFIX + "year" ;
	subCl_Name = CHANGEDPREFIX + "month" ;
   try
   {
      commDropCL( db, COMMCSNAME, subCl_Name + "1", true, true,
                  "clean sub collection" );
      commDropCL( db, COMMCSNAME, subCl_Name + "2", true, true,
                  "clean sub collection" );
      commDropCL( db, COMMCSNAME, MainCL_Name, true, true,
                  "clean main collection" );
   }
   catch( e )
   {
      println( "failed to drop main and sub cl, rc = " + e );
      throw e;
   }

   try {
      var cs = commCreateCS( db, COMMCSNAME, true, "create cs in the beginning" );
   }catch(e){
      println( "failed to create cs, rc = " + e );
      throw e;
   }
	println( COMMCSNAME ) ;
	
	try
	{
		var mainCL = cs.createCL( MainCL_Name, { ShardingKey:{ a:1 }, ShardingType: "range", ReplSize:0, Compressed:true, IsMainCL:true } ) ;
		println( "mainCL" );
		var subCL1 = cs.createCL( subCl_Name + "1", { ShardingKey:{ a:1 }, ShardingType: "range", ReplSize:0, Compressed:true, IsMainCL:false } ) ;
		println( "subCL1" );
		var subCL2 = cs.createCL( subCl_Name + "2", { ShardingKey:{ a:1 }, ShardingType: "range", ReplSize:0, Compressed:true, IsMainCL:false } ) ;
		println( "subCL2" );
		mainCL.attachCL( COMMCSNAME+"."+subCl_Name+"1", { LowBound:{a:0},UpBound:{a:10} } );
		println( "attach subCL1" );
		mainCL.attachCL( COMMCSNAME+"."+subCl_Name+"2", { LowBound:{a:10},UpBound:{a:20} } );
		println( "attach subCL2" );
	}
	catch( e )
	{
		println( " Error: " + e );
		throw e ;
	}

}

// Add inspect standalone run mode
try
{
   // Inspect the run mode is standalone or not
   if( true == commIsStandalone( db ) )
      throw "ModeStandAlone" ;
   test_range_attach_range();
}
catch( e )
{
   if( "ModeStandAlone" == e )
      println( "The run mode is standalone" ) ;
   else
      throw e ;
}
