/* *****************************************************************************
@discretion: subCL basic: subcl range-split
@modify list:
   						2014-01-30 Pusheng Ding  Init
***************************************************************************** */

function test_range_attach_range() // NOT Error, test mainCL'ShardingType is range and subCL's ShardingType is range , attach's result
{
	mainCL_Name = CHANGEDPREFIX + "_year" ;
	subCL_Name1 = CHANGEDPREFIX + "_month1" ;
	subCL_Name2 = CHANGEDPREFIX + "_month2" ;
	try
	{
		var db = new Sdb( COORDHOSTNAME, COORDSVCNAME ) ;
	}
	catch( e )
	{
		println( "can't new Sdb: " );
		throw e ;
	}
	try
	{
      commDropCL( db, COMMCSNAME, subCL_Name1, true, true,
                  "drop sub cl1 in the beginning" ) ;
      commDropCL( db, COMMCSNAME, subCL_Name2, true, true,
                  "drop sub cl2 in the beginning" ) ;
      commDropCL( db, COMMCSNAME, mainCL_Name, true, true,
                  "drop main cl in the beginning" ) ;
	}
	catch( e )
	{
		if( e != -34 )
		{
			println( "can't dropCS, rc=" + e );
			throw e ;
		}
	}
	
	try
	{
      var cs = commCreateCS( db, COMMCSNAME, true, "create CS" );
		var mainCL = cs.createCL( mainCL_Name, { ShardingKey:{ a:1 }, ShardingType: "range", IsMainCL:true } ) ;
		println( "mainCL" );
		var subCL1 = cs.createCL( subCL_Name1, { ShardingKey:{ a:1 }, ShardingType: "range", ReplSize:0, Compressed:true, IsMainCL:false } ) ;
		println( "subCL1" );
		var subCL2 = cs.createCL( subCL_Name2, { ShardingKey:{ a:1 }, ShardingType: "range", ReplSize:0, Compressed:true, IsMainCL:false } ) ;
		println( "subCL2" );
		mainCL.attachCL( COMMCSNAME+"."+subCL_Name1, { LowBound:{a:0},UpBound:{a:10} } );
		println( "attach subCL1" );
		mainCL.attachCL( COMMCSNAME+"."+subCL_Name2, { LowBound:{a:10},UpBound:{a:20} } );
		println( "attach subCL2" );
	}
	catch( e )
	{
		println( " Error: " + e );
		throw e ;
	}
	
}

// Add inspect standalone run mode
try
{
   var db = new Sdb(COORDHOSTNAME, COORDSVCNAME) ;
   // Inspect the run mode is standalone or not
   if( true == commIsStandalone( db ) )
      throw "ModeStandAlone" ;
   test_range_attach_range();
}
catch( e )
{
   if( "ModeStandAlone" == e )
      println( "The run mode is standalone" ) ;
   else
      throw e ;
}
