/*******************************************************************************
*@Description : subCL hash-split
*@Modify List :
*   2015-03-09   xiaojun Hu   Init
*******************************************************************************/

function main( db ) {
   var SUBCLNAME1 = COMMCLNAME + "1";
   var SUBCLNAME2 = COMMCLNAME + "2";
   var SUBCLNAME3 = COMMCLNAME + "3";
   var SUBCLNAME4 = COMMCLNAME + "4";
   db.setSessionAttr( { PreferedInstance: "M" } );
   commDropCL( db, COMMCSNAME, SUBCLNAME1, true, true,
               "clean collection" );
   commDropCL( db, COMMCSNAME, SUBCLNAME2, true, true,
               "clean collection" );
   commDropCL( db, COMMCSNAME, SUBCLNAME3, true, true,
               "clean collection" );
   commDropCL( db, COMMCSNAME, SUBCLNAME4, true, true,
               "clean collection" );
   commDropCL( db, COMMCSNAME, COMMCLNAME, true, true,
               "clean collection" );
   println( "clean colleciton successful" );
   var clOptionObj = { ShardingKey: {no:1}, ShardingType:"range", ReplSize:0,
                       Compressed:true, IsMainCL:true };
   var mainCL = commCreateCLByOption( db, COMMCSNAME, COMMCLNAME, clOptionObj,
                                      true, false, "create main collection" );
   var subCL1 = commCreateCL( db, COMMCSNAME, SUBCLNAME1, -1, true, true, false,
                              "create sub collection 1" );
   var subCL2 = commCreateCL( db, COMMCSNAME, SUBCLNAME2, -1, true, true, false,
                              "create sub collection 2" );
   var subCL3 = commCreateCL( db, COMMCSNAME, SUBCLNAME3, -1, true, true, false,
                              "create sub collection 3" );
   var subCL4 = commCreateCL( db, COMMCSNAME, SUBCLNAME4, -1, true, true, false,
                              "create sub collection 4" );
   println( "create main collection and sub collection successful" );
   mainCL.attachCL( COMMCSNAME + "." + SUBCLNAME1, { LowBound: { no: 1 },
                                                     UpBound: { no: 2500 } } );
   mainCL.attachCL( COMMCSNAME + "." + SUBCLNAME2, { LowBound: { no: 2500 },
                                                     UpBound: { no: 5000 } } );
   mainCL.attachCL( COMMCSNAME + "." + SUBCLNAME3, { LowBound: { no: 5000 },
                                                     UpBound: { no: 7500 } } );
   mainCL.attachCL( COMMCSNAME + "." + SUBCLNAME4, { LowBound: { no: 7500 },
                                                   UpBound: { no: 10000 } } );
   println( "attach sub collection successful" );
   // insert data
   for ( var i = 1 ; i < 10000 ; ++i ) {
      mainCL.insert( { no:i, "description":"testcase for main collection and sub " +
                     "collection, testcase " + i } );
   }
   println( "insert 10000 records successful" );
   var explainQuery = mainCL.find( {$and: [{no:{$gt:5010}}, {no:{$lt:7490}}]}
                                 ).explain( {Run: true} ).toArray();
   queryObj = JSON.parse( explainQuery );
   var clname = COMMCSNAME + "." + SUBCLNAME3;
   if ( queryObj.Name === clname ) {
      println( "expect query from : " + clname );
      println( "actual explain query : " );
      println( explainQuery );
      throw "wrong query data from sub collection";
   }
   if ( 2479 === queryObj.ReturnNum ) {
      println( "expect query number : 2479" );
      println( "actual explain query : " );
      println( explainQuery );
      throw "wrong query number of data from sub collection";
   }
   //println( "query: " + explainQuery );
}

try {
   var db = new Sdb(COORDHOSTNAME,COORDSVCNAME ) ;
   
   //set priority from masterNode
   db.setSessionAttr( {PreferedInstance:"M"} );
   
   if ( false != commIsStandalone( db ) ) {
      println( "run mode is standalone" );
   } else {
      main( db );
      db.close();
   }
} catch ( e ) {
   throw e;
}
