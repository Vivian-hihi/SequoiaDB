//use sql drop CL
SQLCSNAME = CHANGEDPREFIX+"foo" ;

SQLCLNAME = CHANGEDPREFIX+"bar" ;

//clear environment
try
{
  db.dropCS(SQLCSNAME);
}
catch(e)
{
  if ( e != -34)
    {
        println( "unexpected err happened when clear cs:" + e ) ;
        throw e ;
     }
}
//create CS
try
{
	db.execUpdate("create collectionspace "+SQLCSNAME);
}
catch(e)
{
  println("failed to create CS , rc =" +e);
  throw e ;	
}
//create CL
try 
{
	db.execUpdate("create collection "+SQLCSNAME+"."+SQLCLNAME);
}
catch(e)
{
	println("failed to create collection CL , rc = "+e);
	throw e ;
}
//drop CL
try
{
	db.execUpdate("drop collection "+SQLCSNAME+"."+SQLCLNAME);	
}
catch(e)
{
	println("failed to drop CL , rc ="+e);	
	throw e ;
}

//drop again
var res = false ;
try
{
	db.execUpdate("drop collection "+SQLCSNAME+"."+SQLCLNAME);	
}
catch(e)
{
	if( e == -23)
	{
	   res = true ;
	}
	else
	{
	   println( "drop collection " + SQLCSNAME + "." + SQLCLNAME + " failed: " + e ) ;
	}
}
if(!res)
{
   println( "failed1" ) ;
   throw -1 ;
}
//drop a CL,the CL is a empty string
var res = false ;
try
{
	db.execUpdate("drop collection "+SQLCSNAME+"."+"");	
}
catch(e)
{
	if( e == -6)
	{
	   res = true ;
	}
	else
	{
	   println( "drop collection " + SQLCSNAME + "." + "" + " failed: " + e ) ;
	}
}
if(!res)
{
   println( "failed2" ) ;
   throw -1 ;	
}
//drop illegal named cl
var res = false ;
var aa = Array(";",":","\'","\"","{","}","[","]",",","<",">","?","/","|","\\","+","=","-","_","~","`","!","@","#","$","%","^","&","*","(",")","SYS");
for(var i = 0 ; i < aa.length ; ++i ){
   	try{
   	    var CLname = aa[i] + CHANGEDPREFIX ;	
   	    db.execUpdate("drop collection "+SQLCSNAME+"."+CLname);
   	}catch( e ){
   			if(e == -23)
			{
   			   res = true ;
			}
			else
			{
			   println( "drop collection " + SQLCSNAME + "." + CLname + " failed: " + e ) ;
			}
   	}
}

if( !res ){
   println( "failed3" ) ;
   throw -1 ; 
}

//drop a CL,it's length is more than 127B
var CL = "";
for(var i = 0 ; i < 128 ; ++i ){
	  CL = CL+"a";
	}
var res = false ; 
try
{
   db.execUpdate( "drop collection "+SQLCSNAME+"."+CL) ;
}
catch ( e )
{
   // when standalone, result is -6, because name length must <= 127
   // when cluster, coord query to catalog return -23
   if ( e == -23 || e == -6 )
   {
      res = true ;
   }
   else
   {
      println( "drop collection " + SQLCSNAME + "." + CL + " failed: " + e ) ;
   }
}
if( !res ){
   println( "failed4" ) ;
   throw -1 ; 
}
//drop a CL,it's length is 127B
for(var i = 0 ; i < 127-CHANGEDPREFIX.length-3  ; ++i ){
	  SQLCLNAME = SQLCLNAME+"a";
	}
try
{
   db.execUpdate( "create collection "+SQLCSNAME+"."+SQLCLNAME) ;
}
catch ( e )
{
   println("fail to create CL " +  SQLCSNAME + "." + SQLCLNAME + " failed: " + e );
   throw e ;
}

try
{
   db.execUpdate( "drop collection "+SQLCSNAME+"."+SQLCLNAME) ;
}
catch ( e )
{
   println("failed to drop cl " + SQLCSNAME + "." + SQLCLNAME + " failed: " + e );
   throw e ;
}

try
{
  db.dropCS(SQLCSNAME);
}
catch(e)
{
  println( "unexpected err happened when clear cs:" + e ) ;
  throw e ;
}
