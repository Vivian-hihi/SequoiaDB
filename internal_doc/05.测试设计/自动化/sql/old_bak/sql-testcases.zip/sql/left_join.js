//CHANGEDPREFIX = "suse";
SQLCSNAME = CHANGEDPREFIX+"foo" ;
SQLCLNAME = CHANGEDPREFIX+"bar" ;//student table
SQLCLNAME1 = CHANGEDPREFIX+"bar1" ;  //grade table


//clear environment
try
{
   db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
}
catch (e)
{
   if ( e != -34)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}
//create CS
try 
{
	db.execUpdate("create collectionspace "+SQLCSNAME) ;
}
catch( e )
{
	println ("failed to create CS , rc1 = "+e);
	throw e ;
}
//create student table.
try
{
  //db.execUpdate("create collection "+SQLCSNAME+"."+SQLCLNAME);	
  var claSize = new RSize( SQLCSNAME );
  var varCS = db.getCS(SQLCSNAME);
  var varCL = varCS.createCL(SQLCLNAME,{ReplSize:claSize.ReplSize()});
  var varCL1 = varCS.createCL(SQLCLNAME1,{ReplSize:claSize.ReplSize()})
}
catch( e )
{
	println ("failed to create cl , rc = "+e);
	throw e ;
}

try{
   for(var i = 1;i<=100;i++){
      db.execUpdate("insert into " +SQLCSNAME +"." +SQLCLNAME + "(name,id) values(\"A"+i+"\","+i+")" )	;
   }
   for(var i = 1 ; i<= 50;i++){
     db.execUpdate( "insert into " +SQLCSNAME +"." +SQLCLNAME1 + "(user,id) values(\"B"+i+"\","+i+")" );	
   }
}catch( e ){
   println("insert some date failed!!!")
   throw e;	
}

try{
	 println("select A.name , B.user , A.id from "+SQLCSNAME+"."+SQLCLNAME+" as A left outer join "+SQLCSNAME+"."+SQLCLNAME1+ " as B on A.id=B.id order by A.id asc");
   var res = db.exec("select A.name , B.user , A.id from "+SQLCSNAME+"."+SQLCLNAME+" as A left outer join "+SQLCSNAME+"."+SQLCLNAME1+ " as B on A.id=B.id order by A.id asc");	
}catch( e ){
	println("get the result by left outer join failed order by asc!!!");
	throw e ;
}
var number = 0;
while( res.next() ){number++;}
if( 100 != number ){
   println("get the result is error , result number should be 100 , but the number = " + number + " order by asc");
   throw -1;	
}

try{
	 println("select A.name , B.user , B.id from "+SQLCSNAME+"."+SQLCLNAME+" as A left outer join "+SQLCSNAME+"."+SQLCLNAME1+ " as B on A.id=B.id order by B.id desc");
   var res = db.exec("select A.name , B.user , B.id from "+SQLCSNAME+"."+SQLCLNAME+" as A left outer join "+SQLCSNAME+"."+SQLCLNAME1+ " as B on A.id=B.id order by A.id desc");	
}catch( e ){
	println("get the result by left outer join failed order by desc!!!");
	throw e ;
}
var number = 0;
while( res.next() ){number++;}
if( 100 != number ){
   println("get the result is error , result number should be 50 , but the number = " + number + " order by desc");
   throw -2;	
}

try{
	 println("select A.name , B.user , B.id from "+SQLCSNAME+"."+SQLCLNAME+" as A left outer join "+SQLCSNAME+"."+SQLCLNAME1+ " as B on A.id=B.id order by B.id desc");
   var res = db.exec("select A.name , B.user , B.id from "+SQLCSNAME+"."+SQLCLNAME+" as A left outer join "+SQLCSNAME+"."+SQLCLNAME1+ " as B on A.id=B.id order by A.id desc");	
}catch( e ){
	println("get the result by left outer join failed order by desc!!!");
	throw e ;
}

var value = res.current().toObj();
if( value["name"] != "A100" ){
	 println( "get the result is error by value" );
   throw -3;	
}	
try
{
	db.execUpdate("drop collectionspace "+SQLCSNAME);
}
catch(e)
{
  println("failed to drop cs;rc="+e);
  throw e ;	
}
