
SQLCSNAME = CHANGEDPREFIX+"foo" ;
SQLCLNAME = CHANGEDPREFIX+"bar" ;


function main( db )
{
   // Judge transaction is enable ?
   if ( commIsTransEnabled( db ) == false )
   {
      println( "transaction is not enabled" ) ;
      db.close() ;
      return ;
   }

   //clear environment
   try
   {
      db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
   }
   catch (e)
   {
      if ( e != -34)
      {
         println( "unexpected err happened when clear cs:" + e ) ;
         throw e ;
      }
   }

   //create CS
   try 
   {
      db.execUpdate("create collectionspace "+SQLCSNAME) ;
   }
   catch( e )
   {
      println ("failed to create CS , rc1 = "+e);
      throw e ;
   }
   //create CL.
   try
   {
     //db.execUpdate("create collection "+SQLCSNAME+"."+SQLCLNAME);	
     var claSize = new RSize( SQLCSNAME );
     var varCS = db.getCS(SQLCSNAME);
     var varCL = varCS.createCL(SQLCLNAME,{ReplSize:claSize.ReplSize()});
   }
   catch( e )
   {
      println ("failed to create CL , rc2 = "+e);
      throw e ;
   }
   //insert 20 records
   for ( var i = 0 ; i<20 ; i++)
   {
      try
      {
         db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+" (age) values ("+i+")");
      }
      catch(e)
      {
         println("failed to insert records , rc ="+e);
         throw e ;
      }
   }
      
   try
   {
      var cs = db.getCS(SQLCSNAME);
      var cl = cs.getCL(SQLCLNAME);
   }
   catch(e)
   {
      println("failed to get cs or cl ,rc="+e);
      throw e ;
   }

   //start transaction
   try
   {
      db.transBegin();   
   }
   catch(e)
   {
      println("err happend when start transaction,rc="+e);
      throw e ;
   }
   //database operations
   try
   {
      db.execUpdate("update "+SQLCSNAME+"."+SQLCLNAME+" set name=\"Tom\" where age=19");
      //cl.update({$set:{name:"Tom"}},{age:19});
   }
   catch(e)
   {
      println("failed to update the record age=19,rc="+e);
      throw e ;   
   }

   var rc ;
   try
   {
      rc = db.exec("select * from "+SQLCSNAME+"."+SQLCLNAME+" where name=\"Tom\"");
   }
   catch ( e )
   {
      println( "failed to read record name=Tom, rc= " + e ) ;
      throw e ;
   }

   if ( rc.size()!=1 )
   {
      println( " get the record name=Tom happend err" ) ;
      throw -1;
   }
   try
   {
      db.transCommit();   
   }
   catch(e)
   {
      println("failed to commit the transcation,rc="+e);
      throw e ;   
   }

   var rc ;
   try
   {
      rc = db.exec("select * from "+SQLCSNAME+"."+SQLCLNAME+" where name=\"Tom\"");
   }
   catch ( e )
   {
      println( "failed to read record name=Tom, rc= " + e ) ;
      throw e ;
   }

   if ( rc.size()!=1 )
   {
      println( " update operation execute failure after the transcation commit" ) ;
      throw -1;
   }

   //clear enviroment 
   try
   {
      db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
   }
   catch (e)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}

main( db ) ;
