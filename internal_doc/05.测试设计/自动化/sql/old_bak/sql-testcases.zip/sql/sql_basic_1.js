/* *****************************************************************************
@discretion: sql basic: create && DROP CS/CL/INDEX
@modify list:
   						2014-01-30 Pusheng Ding  Init
***************************************************************************** */

csName = CHANGEDPREFIX+"foo" ;
clName = CHANGEDPREFIX+"bar" ;
CHANGEDPREFIX_IND = CHANGEDPREFIX + "_inx" ;

var db = new Sdb( COORDHOSTNAME, COORDSVCNAME ) ;

try
{
   db.execUpdate( "drop collectionspace "+csName ) ;
}
catch (e)
{
   if ( e != -34)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}

//create CS
try 
{
	db.execUpdate("create collectionspace "+csName) ;
}
catch( e )
{
	println ("failed to create CS , rc1 = "+e);
	throw e ;
}
//create CL
try
{
  db.execUpdate("create collection "+csName+"."+clName);	
}
catch( e )
{
	println ("failed to create CL , rc2 = "+e);
	throw e ;
}
//create INDEX
try
{
  db.execUpdate("create index " + CHANGEDPREFIX_IND + " on "+csName+"."+clName+" (age)");
}
catch( e )
{
	println ("failed to create INDEX , rc3 = "+e);
	throw e ;
}

//drop INDEX
try
{
  db.execUpdate("drop index " + CHANGEDPREFIX_IND + " on "+csName+"."+clName);
}
catch( e )
{
	println ("failed to drop INDEX , rc4 = "+e);
	throw e ;
}
//drop CL
try
{
		db.execUpdate("drop collection "+csName+"."+clName);
}
catch(e)
{
	println("failed to drop CS,rc5 = "+e);
	throw e ;
}
//drop CS
try
{
		db.execUpdate("drop collectionspace "+csName);	
}
catch(e)
{
	println("failed to drop CS,rc6 = "+e);
	throw e ;
}
