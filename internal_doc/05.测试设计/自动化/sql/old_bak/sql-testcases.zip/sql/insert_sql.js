//sql insert normal case
SQLCSNAME = CHANGEDPREFIX+"foo" ;

SQLCLNAME = CHANGEDPREFIX+"bar" ; 
try
{
   db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
}
catch ( e )
{
   if ( e != -34)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}

try
{
	db.execUpdate("create collectionspace "+SQLCSNAME);
}
catch(e)
{
  println("failed to create CS , rc =" +e);
  throw e ;	
}
try 
{
	//db.execUpdate("create collection "+SQLCSNAME+"."+SQLCLNAME);
	var claSize = new RSize( SQLCSNAME );
  var varCS = db.getCS(SQLCSNAME);
  var varCL = varCS.createCL(SQLCLNAME,{ReplSize:claSize.ReplSize()});
}
catch(e)
{
	println("failed to create collection CL , rc = "+e);
	throw e ;
}
//insert {name:"Mike",age:20}
try
{
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+" (name,age) values (\"Mike\",20)");
}
catch(e)
{
	println("failed to insert record,rc="+e);
	throw e ;
}

var rc ;
try
{
   rc = db.exec("select name,age from "+SQLCSNAME+"."+SQLCLNAME+" where name=\"Mike\" and age=20");
}
catch ( e )
{
   println( "failed to read record name-mike,age=20, rc= " + e ) ;
   throw e ;
}

if ( 1 != rc.size() )
{
   println( " get more than one record.." ) ;
   throw -1 ;
}

//clear all the records
try
{
  db.execUpdate("delete from "+SQLCSNAME+"."+SQLCLNAME);	
}
catch(e)
{
	println("failed to delete records , rc ="+e);
	throw e ;
}

//insert record {_id:"123",a:10}
try
{
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+" (_id,a) values (\"123\",10)");
}
catch(e)
{
	println("failed to insert record _id=123,a=10,rc1="+e);
	throw e ;
}

var rc ;
try
{
   rc = db.exec("select _id,a from "+SQLCSNAME+"."+SQLCLNAME+" where _id=\"123\" and a=10");
}
catch ( e )
{
   println( "failed to read record _id=123,a=10, rc= " + e ) ;
   throw e ;
}
if ( 1 != rc.size() )
{
   println( " get more than one record...." ) ;
   throw -1 ;
}

//clear all the records
try
{
  db.execUpdate("delete from "+SQLCSNAME+"."+SQLCLNAME);	
}
catch(e)
{
	println("failed to delete records , rc ="+e);
	throw e ;
}

//insert record ,the field contain &,%,$.etc

var res = false ;
var aa = Array("=",">","<","*",";",",","\"");

for(var i = 0 ; i < aa.length ; ++i ){
   	try{
   	    var age = aa[i]+"age";	
   	    db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"("+age+")"+" values(25)");
   	}catch( e ){
   		if ( e == -195 )
   			res = true ;
   	}

if(!res)
{
	println("over...") ;
	throw -1 ;
	
}
res = false ; 
}
//the field values is contain %,*,$.etc
var res = false ;
var aa = Array(";",":","\'","\"","{","}","[","]",",","<",">","?","/","|","\\","+","=","-","_","~","`","!","@","#","$","%","^","&","*");
for(var i = 0 ; i < aa.length ; ++i ){
   	try{
   	    var value = aa[i]+"chen";	
   	    db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name) values"+"("+value+")");
   	}catch( e ){
   		if ( e == -195 )
   			res = true ;
   	}
}
if(!res)
{
	throw -1 ;
}

//clear environment
try
{
   db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
}
catch ( e )
{
   println( "failed to drop cs, rc= " + e ) ;
   throw e ;
}
