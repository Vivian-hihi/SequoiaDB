/* *****************************************************************************
@discretion: sql basic: insert && delete
@modify list:
   						2014-01-30 Pusheng Ding  Init
***************************************************************************** */

csName = CHANGEDPREFIX+"foo" ;
clName = CHANGEDPREFIX+"bar" ;

var db = new Sdb( COORDHOSTNAME, COORDSVCNAME ) ;
try
{
   db.execUpdate( "drop collectionspace "+csName ) ;
}
catch ( e )
{
   if ( e != -34)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}

try
{
	db.execUpdate("create collectionspace "+csName);
}
catch(e)
{
  println("failed to create CS , rc =" +e);
  throw e ;	
}
try 
{
	//db.execUpdate("create collection "+csName+"."+clName);
	var claSize = new RSize( csName );
  var varCS = db.getCS(csName);
  var varCL = varCS.createCL(clName,{ReplSize:claSize.ReplSize()});
}
catch(e)
{
	println("failed to create collection CL , rc = "+e);
	throw e ;
}
//insert {name:"Mike",age:20}
try
{
	db.execUpdate("insert into "+csName+"."+clName+" (name,age) values (\"Mike\",20)");
}
catch(e)
{
	println("failed to insert record,rc="+e);
	throw e ;
}

//verify data
var rc ;
try
{
   rc = db.exec("select name,age from "+csName+"."+clName+" where name=\"Mike\" and age=20");
}
catch ( e )
{
   println( "failed to read record name-mike,age=20, rc= " + e ) ;
   throw e ;
}
if ( 1 != rc.size() )
{
   println( " get more than one record.." ) ;
   throw -1 ;
}

//delete
try
{
	db.execUpdate("delete from "+csName+"."+clName+" where age=20");
}
catch(e)
{
	println("failed to delete the record , rc ="+e);
	throw e ;
}
//verify data
var rc ;
try
{
   rc = db.exec("select name,age from "+csName+"."+clName+" where name=\"Mike\" and age=20");
}
catch ( e )
{
   println( "failed to query record name-mike,age=20, rc= " + e ) ;
   throw e ;
}
if ( 0 != rc.size() )
{
   println( " delete data failed" ) ;
   throw -2 ;
}

//clear environment
try
{
   db.execUpdate( "drop collectionspace "+csName ) ;
}
catch ( e )
{
   println( "failed to drop cs, rc= " + e ) ;
   throw e ;
}
