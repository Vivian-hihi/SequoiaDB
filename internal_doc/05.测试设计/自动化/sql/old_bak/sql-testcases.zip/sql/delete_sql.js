SQLCSNAME = CHANGEDPREFIX+"foo" ;
SQLCLNAME = CHANGEDPREFIX+"bar" ;
//clear environment
try
{
   db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
}
catch (e)
{
   if ( e != -34)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}
//create CS
try 
{
	db.execUpdate("create collectionspace "+SQLCSNAME) ;
}
catch( e )
{
	println ("failed to create CS , rc1 = "+e);
	throw e ;
}
//create CL.
try
{
  //db.execUpdate("create collection "+SQLCSNAME+"."+SQLCLNAME);	
  
   var claSize = new RSize( SQLCSNAME );
   var varCS = db.getCS(SQLCSNAME);
   var varCL = varCS.createCL(SQLCLNAME,{ReplSize:claSize.ReplSize()});
}
catch( e )
{
	println ("failed to create CL , rc2 = "+e);
	throw e ;
}
//insert 7 records
try
{
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Tom\","+1+")");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Mike\","+2+")");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Lisa\","+3+")");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Json\","+4+")");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Jhon\","+5+")");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Tina\","+6+")");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Pite\","+7+")");
}
catch(e)
{
	println("failed to insert records , rc ="+e);
	throw e ;
}
//delete records satisfy the condition
try
{
	db.execUpdate("delete from "+SQLCSNAME+"."+SQLCLNAME+" where age=3");
}
catch(e)
{
	println("failed to delete the record , rc ="+e);
	throw e ;
}

//delete  all the records 
try
{
	db.execUpdate("delete from "+SQLCSNAME+"."+SQLCLNAME);
}
catch(e)
{
	println("failed to delete the record , rc ="+e);
	throw e ;
}
//clear environment
try
{
   db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
}
catch ( e )
{
   println( "failed to drop cs, rc= " + e ) ;
   throw e ;
}
