//use SQL create cs.
// unnormal case. 
SQLCSNAME = CHANGEDPREFIX+"foo" ;

SQLCLNAME = CHANGEDPREFIX+"bar" ;

try
{
	db.execUpdate("drop collectionspace "+SQLCSNAME);
}
catch(e)
{
	if ( e != -34)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}


var aa = Array(";",":","\'","\"","{","}","[","]",",","<",">","?","/","|","\\","+","=","-","_","~","`","!","@","#","$","%","^","&","*","(",")","SYS",".");
for(var i = 0 ; i < aa.length ; ++i ){
        try{
            var CSname = aa[i] + CHANGEDPREFIX ;
            db.execUpdate("drop collectionspace   "+CSname);
        }catch( e ){
        }
}


//the name of cs cannot empty string
var res = false;
try
{
   db.execUpdate("create collectionspace "+" ");
}
catch( e )
{ 
   if(e==-195){
      res = true;
   }
}
if( !res ){
  throw -1;
}


var res = false ;
var aa = Array(";",":","\'","\"","{","}","[","]",",","<",">","?","/","|","\\","+","=","-","_","~","`","!","@","#","$","%","^","&","*","(",")","SYS",".");
for(var i = 0 ; i < aa.length ; ++i ){
   	try{
   	    var CSname = aa[i] + CHANGEDPREFIX ;	
   	    db.execUpdate("create collectionspace "+CSname);
   	}catch( e ){
   			if(e == -6)
   			res = true ;
   	}
}

if( !res ){
   throw -2 ; 
}

//the name of cs's length is 128B
var cs = SQLCSNAME;

for(var i = 0 ; i < 128-SQLCSNAME.length; ++i ){
   cs = cs +"a";	
}
var res = false;
try
{
   db.execUpdate( "create collectionspace "+cs);
}
catch( e )
{ 
   if ( e == -6)
   res = true;

}
if( !res ){
  throw -3;
}

//the cs's length is 127B
for(var i = 0 ; i < 127-SQLCSNAME.length; ++i ){
   SQLCSNAME = SQLCSNAME+"a";	
}



try{ db.dropCS(SQLCSNAME); }catch( e ){ }

try
{
    db.execUpdate( "create collectionspace "+SQLCSNAME );
}
catch( e )
{ 
    println( "unexpected err happened when create cs:" + e ) ;
    throw e;
}

try
{
	db.execUpdate("drop collectionspace "+SQLCSNAME);
}
catch(e)
{
	println("failed to drop 127B CS, rc="+e);
	throw e ;	
}
var aa = Array(";",":","\'","\"","{","}","[","]",",","<",">","?","/","|","\\","+","=","-","_","~","`","!","@","#","$","%","^","&","*","(",")","SYS",".");
for(var i = 0 ; i < aa.length ; ++i ){
        try{
            var CSname = aa[i] + CHANGEDPREFIX ;
            db.execUpdate("drop collectionspace   "+CSname);
        }catch( e ){
        }
}
