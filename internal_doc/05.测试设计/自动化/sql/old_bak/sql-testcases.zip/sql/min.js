//function min
SQLCSNAME = CHANGEDPREFIX+"foo" ;

SQLCLNAME = CHANGEDPREFIX+"bar" ;

//clear environment
try
{
   db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
}
catch (e)
{
   if ( e != -34)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}
//create CS
try 
{
	db.execUpdate("create collectionspace "+SQLCSNAME) ;
}
catch( e )
{
	println ("failed to create CS , rc1 = "+e);
	throw e ;
}
//create CL.
try
{
  //db.execUpdate("create collection "+SQLCSNAME+"."+SQLCLNAME);	
  var claSize = new RSize( SQLCSNAME );
  var varCS = db.getCS(SQLCSNAME);
  var varCL = varCS.createCL(SQLCLNAME,{ReplSize:claSize.ReplSize()});
}
catch( e )
{
	println ("failed to create CL , rc2 = "+e);
	throw e ;
}
//insert records
try 
{
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Tom\",20)");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Tomi\",20)");	
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Miko\",30)");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Mike\",30)");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Tina\",40)");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Timiko\",40)");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Poo\",40)");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Pete\",40)");
	db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Jhon\",10)");
}
catch(e)
{
	println("failed to insert 9 records,rc="+e);
	throw e ;
}
//select min(age) from table 
var rc ;
try
{
	rc = db.exec("select min(age) as min_age from "+SQLCSNAME+"."+SQLCLNAME);	
}
catch(e)
{
	println("err happend when use min,rc="+e);
	throw e ;	
}

var min_age = 0 ;
var obj =eval('('+rc[0]+')') ; 
min_age = obj["min_age"] ; 
if(10!= min_age)
{
	throw -1 ;
	}
	
//clear enviroment
try
{
	db.execUpdate("drop collectionspace "+SQLCSNAME);	
}
catch(e)
{
	println("err happend when clear cs,rc="+e);
	throw e ;	
}
