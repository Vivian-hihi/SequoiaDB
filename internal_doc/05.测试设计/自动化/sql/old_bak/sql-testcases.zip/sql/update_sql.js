
SQLCSNAME = CHANGEDPREFIX+"foo" ;
SQLCLNAME = CHANGEDPREFIX+"bar" ;


//clear environment
try
{
   db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
}
catch (e)
{
   if ( e != -34)
   {
      println( "unexpected err happened when clear cs:" + e ) ;
      throw e ;
   }
}

//create CS
try 
{
   db.execUpdate("create collectionspace "+SQLCSNAME) ;
}
catch( e )
{
   println ("failed to create CS , rc1 = "+e);
   throw e ;
}
//create CL.
try
{
  //db.execUpdate("create collection "+SQLCSNAME+"."+SQLCLNAME);   
  var claSize = new RSize( SQLCSNAME );
  var varCS = db.getCS(SQLCSNAME);
  var varCL = varCS.createCL(SQLCLNAME,{ReplSize:claSize.ReplSize()});
}
catch( e )
{
   println ("failed to create CL , rc2 = "+e);
   throw e ;
}

//insert 7 records
try
{
   db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Tom\","+1+")");
   db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Mike\","+2+")");
   db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Lisa\","+3+")");
   db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Json\","+4+")");
   db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Jhon\","+5+")");
   db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Tina\","+6+")");
   db.execUpdate("insert into "+SQLCSNAME+"."+SQLCLNAME+"(name,age) values(\"Pite\","+7+")");
}
catch(e)
{
   println("failed to insert records , rc ="+e);
   throw e ;
}

//update all the records:add a field,it's name is phone and value is 123
try
{
  db.execUpdate("update "+SQLCSNAME+"."+SQLCLNAME+" set phone=123");   
}
catch(e)
{
   println("failed to update the records , rc ="+e);
   throw e ;
}
//update one record
try
{
  db.execUpdate("update "+SQLCSNAME+"."+SQLCLNAME+" set age=10 where name=\"Lisa\"");   
}
catch(e)
{
   println("failed to update the record , rc ="+e);
   throw e ;
}
var rc ;
try
{
   rc=db.exec("select * from "+SQLCSNAME+"."+SQLCLNAME+" where age=10")   
}
catch(e)
{
   println("failed to read the record age=10 , rc="+e);
   throw e ;   
}
if( 1 != rc.size() )
{
   println("get more than one records");
}

//update records satisfy the condition
try
{
   db.execUpdate("update "+SQLCSNAME+"."+SQLCLNAME+" set phone=456 where age>4");   
}
catch(e)
{
   println("failed to update the record , rc ="+e);
   throw e ;
}

//clear environment
try
{
   db.execUpdate( "drop collectionspace "+SQLCSNAME ) ;
}
catch ( e )
{
   println( "failed to drop cs, rc= " + e ) ;
   throw e ;
}
